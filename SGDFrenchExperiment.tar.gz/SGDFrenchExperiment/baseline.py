import loadLib
from virony import data

from sklearn import metrics
from sklearn.cross_validation import train_test_split
import cPickle
import numpy as np
import sys

dataset = sys.argv[1]
experiment = sys.argv[2]
nb_run = int(sys.argv[3])



X,y, targetEncoder = data.load("dataset/"+dataset+"_"+experiment+"_10bit")


confusions = np.zeros((nb_run, len(targetEncoder), len(targetEncoder)), dtype=float)
for run_id in range(0,nb_run):
        
    seeds = np.random.randint(1000, size=2)
    X_train, X_test, y_train, y_test = train_test_split(X,y,train_size=0.7, random_state=seeds[0])


    # Extract counts and categorical probabilities
    proba = np.zeros(len(targetEncoder),dtype=float)
    for label in y_train:
        proba[label] += 1
    proba /= proba.sum()
    
    
    y_pred = np.random.multinomial(1, proba, y_test.size).argmax(axis=1)
    y_true = y_test
    confusions[run_id] = metrics.confusion_matrix(y_true, y_pred)
    accuracy = float(confusions[run_id].trace())/confusions[run_id].sum()

    report = metrics.classification_report(y_true, y_pred, target_names=map(str,targetEncoder.classes_)) + "\n"
    report += "Accuracy :"+str(accuracy)+"\n\n"

    print "Run_id: ", run_id
    print
    print report
    print
    print "#################################################"
    print
    print

with open("clf_reports/confusion_matrix__tweetFR_"+experiment+"_baseline.pickle", "wb") as fout:
    cPickle.dump(confusions, fout)
