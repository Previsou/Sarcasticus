from virony import data

from sklearn.linear_model import SGDClassifier
from sklearn import metrics
from sklearn.cross_validation import train_test_split
from sklearn.grid_search import GridSearchCV
import cPickle
import numpy as np
from scipy import sparse
import sys

dataset = sys.argv[1]
experiment = sys.argv[2]
n_bits = int(sys.argv[3])
n_iter = int(sys.argv[4])
nb_run = int(sys.argv[5])
n_jobs = int(sys.argv[6])

cv = 10

param_grid = [  {'penalty':['l1', 'l2'], 'loss':['hinge', 'log', 'modified_huber'], 'alpha': [10e-6,10e-5,10e-4,10e-3,10e-2]},
                ]
score_func=metrics.precision_score
    
    
X,y, targetEncoder = data.load("dataset/"+dataset+"_"+experiment+"_"+str(n_bits)+"bit")
keep = targetEncoder.transform(["False", "True"])
select = np.array([(i==keep[0]) or (i==keep[1]) for i in y])
y = y[select]
X = sparse.vstack([X[row] for row,i in enumerate(select) if i]).tocsr()

confusions = np.zeros((nb_run, len(targetEncoder), len(targetEncoder)), dtype=float)
#confusions = np.zeros((nb_run, 2,2), dtype=float)
for run_id in range(0,nb_run):
        
    seeds = np.random.randint(1000, size=2)
    X_train, X_test, y_train, y_test = train_test_split(X,y,train_size=0.7, random_state=seeds[0])


    clf = GridSearchCV(SGDClassifier(random_state=seeds[1], shuffle=True, n_iter=n_iter, learning_rate="optimal"), param_grid, score_func=score_func, verbose=True, n_jobs=n_jobs)
    clf.fit(X_train, y_train, cv=cv)

    y_pred, y_true = clf.predict(X_test), y_test
    confusions[run_id] = metrics.confusion_matrix(y_true, y_pred)
    accuracy = float(confusions[run_id].trace())/confusions[run_id].sum()

    report = metrics.classification_report(y_true, y_pred, target_names=map(str,targetEncoder.classes_)) + "\n"
    #report = metrics.classification_report(y_true, y_pred, target_names=targetEncoder.inverse_transform([0,1])) + "\n"
    report += "Accuracy :"+str(accuracy)+"\n\n"
    report += str(clf.best_estimator_)+"\n\n"

    print "Run_id: ", run_id
    print
    print report
    print
    print "#################################################"
    print
    print

with open("clf_reports/confusion_matrix_"+dataset+"_"+experiment+"_"+str(n_bits)+"bit.pickle", "wb") as fout:
    cPickle.dump(confusions, fout)
    
