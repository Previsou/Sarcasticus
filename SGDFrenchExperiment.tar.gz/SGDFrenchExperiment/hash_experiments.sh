#!/bin/bash

ipython baseline.py $1 coarse 100 > clf_reports/hash_coarse_baseline.txt
ipython sgd_clf.py $1 coarse 10 10 100 7 > clf_reports/hash_coarse_10bit.txt
ipython sgd_clf.py $1 coarse 16 10 100 7 > clf_reports/hash_coarse_16bit.txt
ipython sgd_clf.py $1 coarse 20 10 100 7 > clf_reports/hash_coarse_20bit.txt

ipython baseline.py fine 100 > clf_reports/hash_fine_baseline.txt
ipython sgd_clf.py $1 fine 10 10 100 7 > clf_reports/hash_fine_10bit.txt
ipython sgd_clf.py $1 fine 16 10 100 7 > clf_reports/hash_fine_16bit.txt
ipython sgd_clf.py $1 fine 20 10 100 7 > clf_reports/hash_fine_20bit.txt
