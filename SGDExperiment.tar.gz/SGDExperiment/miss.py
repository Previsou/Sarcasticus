"""
    Script: miss.py
    Author: Lubin Maxime <maxime@soft.ics.keio.ac.jp>
    Date: 2013-07-24
    This module is part of the code I wrote for my master research project at Keio University (Japan)
    
    Simple script to analyze misclassified documents of a classification task.
    This script assumes misclassified items are stored in "data/clf_miss.dataframe"
    
    Analysis performed:
        - extract ratio of misclassified tweets
        - extract label distribution of misclassified items
        - histogram of length of missed items
        - error(length) plot
        - distribution of linguistic features over misclassified documents
        
    Args:
        str::dataset: name of the dataset to load (misclassifeid and corpus)
    Return:
        None, results are printed or saved under "analysis/miss/dataset/grain/graphs/"
"""

from pandas import load
import matplotlib.pyplot as plt
from collections import Counter
from virony.nlp import tokenize
from virony.data.analyzer import getFeatureDataFrame
import sys

def isTweet(text):
    return "#" in text or "@" in text


if __name__ == "__main__":
    
    # Script arguments
    dataset = sys.argv[1]
    
    # Intermediate data
    missclf = load("data/"+dataset+"_miss.dataframe")
    complexF = getFeatureDataFrame(dataset+"_fine")
    labelDist = complexF.groupby("label").size()
    complexF = complexF.ix[missclf.index]
    miss_labels = Counter(missclf.label.dropna())
    tweet_ratio = sum(1.0 for text in missclf.text if isTweet(text)) / len(missclf)
    error_kde = missclf.proba -0.5
    lengths = [len(tokenize(text,False)) for text in missclf.text]
    
    
    # Print report
    report = u"\t\t\tAnalysis of misclassified documents\n\n\n"
    report += u"Total number: %d / %d (%f%)\n\n" % (len(missclf),
                    labelDist.sum(), len(missclf)/float(labelDist.sum()))
    report += u"Tweet ratio: %f\n\n" % tweet_ratio
    report += u"Label distribution:\n"
    for label, count in miss_labels:
        report += u"\t- %s: %d / %d (%f%)" % (label, count, labelDist[label],
                                                float(count)/labelDist[label])
    
    with open("analysis/miss/"+dataset+"miss_summary.txt", "w") as fout:
        fout.write(report)
    print(report)
    
    # Compute plots
    ###  Distribution of length of misclassified documents  ###
    plt.hist([l for l in lengths if l<1500], bins=50)
    plt.xlabel("length")
    plt.ylabel("#missclassified doc")
    plt.savefig("analysis/miss/"+dataset+"/graphs/length_histogram")
    plt.show()

    ### Gaussian Kernel Density Estimation of the distribution of  ###
    ### linguistic features over misclassifed documents            ###
    for feature in (f for f in complexF.columns if f!="irony"):
        try:
            complexF[feature].plot(kind="kde", title=feature)
            plt.legend(loc="best")
            plt.savefig("analysis/miss/"+dataset+"/graphs/"+feature+"_kde")
            plt.clf()
        except:
            print feature

    #### Plot error vs length  ###
    plt.plot(lengths,error_kde.values,"bo")
    plt.xlabel("length")
    plt.ylabel("classification error")
    plt.title("Influence of the document's length on classification error")
    plt.savefig("analysis/miss/"+dataset+"/graphs/pred_error_VS_length")
    plt.grid(True)
    plt.show()
