#!/bin/bash


ipython baseline.py $1 coarse 20 > clf_reports/$1/hash_coarse_baseline.txt
ipython sgd_clf.py $1 coarse 8 10 20 7 > clf_reports/$1/hash_coarse_8bit.txt
ipython sgd_clf.py $1 coarse 10 10 20 7 > clf_reports/$1/hash_coarse_10bit.txt
ipython sgd_clf.py $1 coarse 12 10 20 7 > clf_reports/$1/hash_coarse_12bit.txt
ipython sgd_clf.py $1 coarse 14 10 20 7 > clf_reports/$1/hash_coarse_14bit.txt
ipython sgd_clf.py $1 coarse 16 10 20 7 > clf_reports/$1/hash_coarse_16bit.txt
ipython sgd_clf.py $1 coarse 18 10 20 7 > clf_reports/$1/hash_coarse_18bit.txt
ipython sgd_clf.py $1 coarse 20 10 20 7 > clf_reports/$1/hash_coarse_20bit.txt

ipython baseline.py $1 fine 20 > clf_reports/$1/hash_fine_baseline.txt
ipython sgd_clf.py $1 fine 8 10 20 7 > clf_reports/$1/hash_fine_8bit.txt
ipython sgd_clf.py $1 fine 10 10 20 7 > clf_reports/$1/hash_fine_10bit.txt
ipython sgd_clf.py $1 fine 12 10 20 7 > clf_reports/$1/hash_fine_12bit.txt
ipython sgd_clf.py $1 fine 14 10 20 7 > clf_reports/$1/hash_fine_14bit.txt
ipython sgd_clf.py $1 fine 16 10 20 7 > clf_reports/$1/hash_fine_16bit.txt
ipython sgd_clf.py $1 fine 18 10 20 7 > clf_reports/$1/hash_fine_18bit.txt
ipython sgd_clf.py $1 fine 20 10 20 7 > clf_reports/$1/hash_fine_20bit.txt
