"""
    Script: baseline.py
    Author: Lubin Maxime <maxime@soft.ics.keio.ac.jp>
    Date: 2013-07-23
    This module is part of the code I wrote for my master research project at Keio University (Japan)
    
    Simple script to generate baseline of classification experiments.
    The baseline consists in randomly sampling the random training set label distribution.
    
    Args:
        str::dataset: name of the dataset to load (created by virony.buildDataset.py)
        str::grain: "coarse" for regular/virony classification, "fine" for multiclass
        int::nb_run: number of times to repeat the experiment
    
    Return:
        print classification result for each experiment
        save clf metrics in a matrix, under "clf_reports/dataset/confusion_matrix_grain_baseline.pickle"
"""

from virony import data
from sklearn import metrics
from sklearn.cross_validation import train_test_split
import cPickle
import numpy as np
import sys

dataset = sys.argv[1]
grain = sys.argv[2]
nb_run = int(sys.argv[3])

#-----------------------------------------------------------------------
#-----------------------------------------------------------------------

# Load dataset
X,y, targetEncoder = data.load("dataset/"+dataset+"_"+grain)


confusions = np.zeros((nb_run, len(targetEncoder), len(targetEncoder)), dtype=float)
for run_id in range(0,nb_run):
    
    # random split of the data
    seeds = np.random.randint(1000, size=2)
    X_train, X_test, y_train, y_test = train_test_split(X,y,train_size=0.7, random_state=seeds[0])


    # Extract counts and categorical probabilities
    proba = np.zeros(len(targetEncoder),dtype=float)
    for label in y_train:
        proba[label] += 1
    proba /= proba.sum()
    
    # Random prediction
    y_pred = np.random.multinomial(1, proba, y_test.size).argmax(axis=1)
    y_true = y_test
    
    # Compute confusion matrix
    confusions[run_id] = metrics.confusion_matrix(y_true, y_pred)
    
    # Compute accuracy
    accuracy = float(confusions[run_id].trace())/confusions[run_id].sum()

    # Compute clf metrics: precision, recall, F1 score and support.
    # Create classification report
    report = metrics.classification_report(y_true, y_pred, target_names=map(str,targetEncoder.classes_)) + "\n"
    report += "Accuracy :"+str(accuracy)+"\n\n"

    print "Run_id: ", run_id
    print
    print report
    print
    print "#################################################"
    print
    print

# Save confusion matrix of all the runs
with open("clf_reports/"+dataset+"/confusion_matrix_"+grain+"_baseline.pickle", "wb") as fout:
    cPickle.dump(confusions, fout)
