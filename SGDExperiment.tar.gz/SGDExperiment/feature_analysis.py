"""
    Script: feature_analysis.py
    Author: Lubin Maxime <maxime@soft.ics.keio.ac.jp>
    Date: 2013-07-24
    This module is part of the code I wrote for my master research project at Keio University (Japan)
    
    Simple script to analyze (plot, statistical tests) the features of a trained model
    and their distribution over a corpus.
    
    Args:
        str::dataset: name of the dataset to load (created by virony.buildDataset.py)
        str::grain: "coarse" for regular/virony classification, "fine" for multiclass
        str::column_label: number of times to repeat the experiment
    
    Return:
        None, all results are saved under "analysis/dataset_name"
"""

from virony.data import analyzer, load
from pandas import DataFrame
import matplotlib.pyplot as plt
import sys


def style(freqs, tokens):
    """
    Analyze styilistic differences between 2 sample.
    
    Args:
        {"irony":dict,"regular":dict}::freqs: contains token frequency information, for the  samples.
                                            (created with virony/bin/buildTF.py)
    
    Return:
        A plot (see matplotlib.pyplot for further detail).
    """
    style = DataFrame([freqs["irony"][tok] for tok in tokens], index=tokens, columns=["irony"])
    style["regular"] = [freqs["regular"][tok] for tok in tokens]
    irony_norm = float(style.irony.sum())
    regular_norm = float(style.regular.sum())
    
    styleDiff = style.irony/irony_norm - style.regular/regular_norm
    return styleDiff[abs(styleDiff)>0.001].plot(kind="barh", \
                                            title="Stylistic differences between ironic/non-ironic texts")


if __name__ == "__main__":

    # Script arguments
    dataset_name = sys.argv[1]
    grain = sys.argv[2]
    column_label = sys.argv[3]
    
    
    # Load and preprare the data
    dataset = analyzer.getFeatureDataFrame(dataset_name+"_"+grain)
    dataset["abs_polarity"] = abs(dataset.polarity_mean)
    
    freqs = load("TF/"+dataset_name+"_term_freqs.pickle")
    
    tokens = list(load("wordlist/punctuation"))
    tokens += list(load("wordlist/stopword_en").word)
    
    
    # Compute feature correlation
    for value, corrs in analyzer.correlation(dataset, column_label=column_label).iteritems():
        corrs.to_csv("analysis/"+dataset_name+"/"+grain+"_label_"+value+"_correlations.csv")
    
    # Perform 2-smaple Kolmogorov-Smirnov and Welch tests
    with open("analysis/"+dataset_name+"/"+grain+"_stat_tests.txt", "w") as fout:
        fout.write(u"\t\tKolmogorov-Smirnov test\n\n")
        for feature, (D, p_value) in analyzer.KS_test(dataset, column_label=column_label).iteritems():
            fout.write(u"{}: D={}, p-value={}\n".format(feature, D, p_value))
        
        fout.write("\n\n\t\t####################################\n\n")
        
        fout.write(u"\t\t2-sided Student's t test (unequal variance)\n\n")
        for feature, (t, p_value) in analyzer.Welch_test(dataset, column_label=column_label).iteritems():
            fout.write(u"{}: t={}, p-value={}\n".format(feature, t, p_value))
            
        fout.write("\n\n\t\t####################################\n\n")
        
        alpha = 0.01 # "Risk of the first kind"?? (probably a bad translation from French...)
        fout.write(u"\t\tConfidence intervals for the mean (alpha="+str(alpha)+")\n\n")
        fout.write(analyzer.mean_intervals(dataset, column_label, alpha).to_string()+"\n\n\n")
    
    # Analyse stylistic differences
    style(freqs,tokens)
    plt.show()
    
    # Analyze the features: Kernel Density Estimation, parallel coordinates.
    analyzer.analyze1D(dataset, column_label=column_label, out="analysis/"+dataset_name+"/graphs/"+grain+"/")
    analyzer.parallelCoordinates(dataset, column_label=column_label, out="analysis/"+dataset_name+"/graphs/"+grain+"/")
    
