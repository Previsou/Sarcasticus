"""
    Script: pr_plot.py
    Author: Lubin Maxime <maxime@soft.ics.keio.ac.jp>
    Date: 2013-07-23
    This module is part of the code I wrote for my master research project at Keio University (Japan)
    
    Simple script to generate a precision-recall plot of a repeated experiment.
    The figure is splitted into 2 (or 4 for fine grain), each space corresponding to one label.
    Some state-of-the-art experiment are added to the figure.
    
    Args:
        str::dataset: name of the dataset to load (created by virony.buildDataset.py)
        str::grain: "coarse" for regular/virony classification, "fine" for multiclass
        bool::hashed: If True, use hash-based models.
    
    Return:
        Display the plot
"""

import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from collections import OrderedDict
import cPickle
import pandas
import os
import sys

#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
#   Arguments

dataset = sys.argv[1]
grain = sys.argv[2]
hashed = sys.argv[3].find("hash")!=-1

#-----------------------------------------------------------------------
#-----------------------------------------------------------------------

# State-of-the-art performance
others = [  {"author":"Burfoot", "label":"satire", "Prec.":0.958, "Rec.":0.680, "sign_x":1, "sign_y":-1},
            {"author":"Reyes", "label":"irony", "Prec.":0.771, "Rec.":0.725, "sign_x":1, "sign_y":1}
        ]


if hashed:
    models = {  "baseline":"Black", "8bit":"Blue", 
                "10bit":"Yellow", "12bit":"Orange", "14bit":"Red",
                "16bit":"YellowGreen", "18bit":"Lime", "20bit":"Purple",
        }
else:
   models = {  'baseline':'Blue', 'cmp':'Green', 'bow':'Orange', 'full':'Red'}
        
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------

formatter = FuncFormatter(lambda tick,pos: abs(tick))

def getScores(mat):
    
    scores = {}
    scores["Rec."] = mat.diagonal() / mat.sum(axis=1)
    scores["Prec."] = mat.diagonal() / mat.sum(axis=0)
    
    return scores
    
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
#   Load experiment confusion matrices and extract scores of each

table = []
for mat_name in models:
    with open("clf_reports/"+dataset+"/confusion_matrix_"+grain+"_"+mat_name+".pickle", "rb") as fin:
        mat = cPickle.load(fin)
    
    temp_table = []
    for i in range(mat.shape[0]):
        scores = getScores(mat[i]) 
        temp = pandas.DataFrame.from_dict(scores)
        temp = temp.reindex_axis(["Prec.", "Rec."], axis=1)
        
        if grain=="fine":
            if dataset == "tweet_sub":
                temp.index = ["regular", "irony", "sarcasm"]
            else:
                try:
                    temp.index = ["regular", "irony", "satire", "sarcasm"]
                except:
                    temp.index = ["regular", "irony", "satire", "sarcasm", "nan"]
        else:
            temp.index = ["regular", "virony"]
        
        temp_table.append(temp)
    table.append(pandas.concat(temp_table))

table = pandas.concat(table, keys=models)

#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
if grain=="coarse":
    # Plot coarse grain PR plot
    fig = plt.figure("pr_plot_%s_%s" % (dataset, grain))
    ax = fig.add_subplot("111")
    
    ax.xaxis.set_major_formatter(formatter)
    ax.yaxis.set_major_formatter(formatter)
    
    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
    
    for model, group in table.groupby(level=0):
        color = models[model]
                
        for label, subgroup in group.groupby(level=1):
            if label=="regular":
                sign = -1
            else:
                sign = 1

            ax.scatter(sign * subgroup["Prec."], subgroup["Rec."], label=model, c=color, s=60, alpha=0.5)

    # Add state-of-the-art results
    for study in others:
        ax.scatter(study["Prec."], study["Rec."], s=150, c="Black", marker="+")
        ax.text(study["Prec."]-0.12, study["Rec."]+0.03, study["author"], fontsize=26)
    
    ax.grid(True)
    
    # For non-repeting labels
    handles, labels = plt.gca().get_legend_handles_labels()
    by_label = OrderedDict(zip(labels, handles))
    ax.legend(by_label.values(), by_label.keys(), loc="upper center", prop={'size':24})

    ax.text(0.4, 0.25,'regular', fontsize=28, horizontalalignment='center', verticalalignment='center', transform = ax.transAxes)
    ax.text(0.6, 0.25,'virony', fontsize=28, horizontalalignment='center', verticalalignment='center', transform = ax.transAxes)
    ax.set_title("Precision-recall plot on %s" % dataset, fontsize=28)
    ax.set_xlabel("precision", fontsize=24)
    ax.set_ylabel("recall", fontsize=24)
    ax.set_xlim((-1,1))
    ax.set_ylim((0,1))
    
    plt.show()


#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
elif grain=="fine":
    # Plot coarse grain PR plot
    fig = plt.figure("pr_plot_%s_%s" % (dataset, grain))
    ax = fig.add_subplot("111")
    
    ax.xaxis.set_major_formatter(formatter)
    ax.yaxis.set_major_formatter(formatter)
    
    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
    
    for model, group in table.groupby(level=0):
        color = models[model]
            
        for label, subgroup in group.groupby(level=1):
            if label=="irony":
                sign_x, sign_y = 1,1
            elif label=="regular":
                sign_x, sign_y = -1, 1
            elif label=="sarcasm":
                sign_x, sign_y = -1,-1
            elif label=="satire":
                sign_x, sign_y = 1,-1
            else:
                continue
                
            ax.scatter(sign_x*subgroup["Prec."], sign_y*subgroup["Rec."], label=model, c=color, s=60, alpha=0.5)

    # Add state-of-the-art results
    for study in others:
        ax.scatter(study["sign_x"] * study["Prec."], study["sign_y"] * study["Rec."], s=150, c="Black", marker="+")
        ax.text(study["sign_x"]*study["Prec."]-0.15, study["sign_y"]*study["Rec."]+0.03, study["author"], fontsize=26)

    ax.grid(True)
    
    # For non-repeting labels
    handles, labels = plt.gca().get_legend_handles_labels()
    by_label = OrderedDict(zip(labels, handles))
    ax.legend(by_label.values(), by_label.keys(), loc="upper center", prop={'size':24})
    
    ax.set_title("Precision-recall plot on %s" % dataset, fontsize=28)
    ax.text(0.3, 0.7,'regular', fontsize=28, horizontalalignment='center', verticalalignment='center', transform = ax.transAxes)
    ax.text(0.3, 0.3,'sarcasm', fontsize=28, horizontalalignment='center', verticalalignment='center', transform = ax.transAxes)
    ax.text(0.7, 0.3,'satire', fontsize=28, horizontalalignment='center', verticalalignment='center', transform = ax.transAxes)
    ax.text(0.7, 0.7,'irony', fontsize=28, horizontalalignment='center', verticalalignment='center', transform = ax.transAxes)
    ax.set_xlabel("precision", fontsize=24)
    ax.set_ylabel("recall", fontsize=24)
    ax.set_xlim((-1,1))
    ax.set_ylim((-1,1))
    
    plt.show()
