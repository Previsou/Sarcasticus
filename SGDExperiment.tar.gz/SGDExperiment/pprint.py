"""
    Script: pprint.py
    Author: Lubin Maxime <maxime@soft.ics.keio.ac.jp>
    Date: 2013-07-23
    This module is part of the code I wrote for my master research project at Keio University (Japan)
    
    Simple script to report the average scores of repeated classification experiments.
    
    Args:
        str::dataset: name of the dataset used in the experiment
        str::grain: grain used in the experiment ("coarse" or "fine")
        bool::hashed: If Tru, use hash-based models.
        
    Return:
        print the report
"""

import cPickle
import pandas
import sys

#-----------------------------------------------------------------------
#-----------------------------------------------------------------------

dataset = sys.argv[1]
grain = sys.argv[2]
hashed = sys.argv[3]

if hashed:
    models = ["baseline"]+["{}bit".format(i) for i in range(8,21,2)]
else:
    models = ["baseline", "cmp", "bow", "full"]
    
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
    
def getScores(mat):
    
    avg_mat = mat.mean(axis=0)
    scores = {}
    scores["Rec."] = avg_mat.diagonal() / avg_mat.sum(axis=1)
    scores["Prec."] = avg_mat.diagonal() / avg_mat.sum(axis=0)
    scores["Support"] = avg_mat.sum(axis=1)
    scores["F1"] = 2./(1/scores["Prec."]+1/scores["Rec."])
    
    return scores, avg_mat.trace()/avg_mat.sum()

#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
#   Compute scores average

table, accuracies = [], {}
runs = 0
for mat_name in models:
    with open("clf_reports/"+dataset+"/confusion_matrix_"+grain+"_"+mat_name+".pickle", "rb") as fin:
        mat = cPickle.load(fin)
    runs = mat.shape[0]
    scores, accuracies[mat_name] = getScores(mat)
    temp = pandas.DataFrame.from_dict(scores)
    temp = temp.reindex_axis(["Prec.", "Rec.", "F1", "Support"], axis=1)
    
    if grain=="fine":
        if dataset == "tweet_sub":
            temp.index = ["regular", "irony", "sarcasm"]
        else:
            temp.index = ["regular", "irony", "satire", "sarcasm"]
    else:
        temp.index = ["regular", "virony"]
    
    table.append(temp)

# Final formatting
accuracies = pandas.Series(accuracies, name="Accuracy", index=models)
table = pandas.concat(table, keys=models)
 
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
#   Print the report
    
print "\t\t"+dataset.upper()+" CLASSIFICATION REPORT\n\n"
print "Average over %d run\n\n" % runs
print table.to_string()
print "\n"
print "Accuracy:\n"
print accuracies.to_string()
print "\n\n"
