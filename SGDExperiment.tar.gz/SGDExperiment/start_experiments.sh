#!/bin/bash

ipython baseline.py $1 coarse 100 > clf_reports/$1/coarse_baseline.txt
ipython sgd_clf.py $1 coarse cmp 10 100 7 > clf_reports/$1/coarse_cmp.txt
ipython sgd_clf.py $1 coarse bow 10 100 7 > clf_reports/$1/coarse_bow.txt
ipython sgd_clf.py $1 coarse full 10 100 7 > clf_reports/$1/coarse_full.txt

ipython baseline.py $1 fine 100 > clf_reports/$1/fine_baseline.txt
ipython sgd_clf.py $1 fine cmp 10 100 7 > clf_reports/$1/fine_cmp.txt
ipython sgd_clf.py $1 fine bow 10 100 7 > clf_reports/$1/fine_bow.txt
ipython sgd_clf.py $1 fine full 10 100 7 > clf_reports/$1/fine_full.txt
