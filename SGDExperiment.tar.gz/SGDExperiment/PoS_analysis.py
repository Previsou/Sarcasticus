"""
    Script: PoS_analysis.py
    Author: Lubin Maxime <maxime@soft.ics.keio.ac.jp>
    Date: 2013-07-24
    This module is part of the code I wrote for my master research project at Keio University (Japan)
    
    Simple script to extract frequencies of Part-of-Speeches of a corpus.
    
    Args:
        str::corpus_name
        int::n_jobs: number of processors to use
    
    Return:
        None, results are saved under "data/corpus_name_pos_freqs.pickle"
"""

import loadLib
from collections import Counter
from virony import data, nlp, parallel
import sys
import cPickle
import nltk

corpus_name = sys.argv[1]
n_jobs = sys.argv[2]

corpus = data.load("corpus/"+corpus_name+".pandas")
tagger = nltk.data.load('taggers/maxent_treebank_pos_tagger/english.pickle')


def posCount(text):
    tags = tagger.tag(nlp.tokenize(text, False))
    return Counter(tag[1] for tag in tags)

PoS = {}
for label, group in corpus.groupby("irony"):
    PoS[label] = Counter()
    print "GROUP::"+str(label).upper()
    N = len(group)
    for i, pos_tags in parallel.parallel_imap(posCount, group.text, n_jobs=n_jobs):
        PoS[label].update(pos_tags)
    
    
with open("data/"+corpus_name+"_pos_freqs.pickle", "wb") as fout:
    cPickle.dump(PoS, fout)
