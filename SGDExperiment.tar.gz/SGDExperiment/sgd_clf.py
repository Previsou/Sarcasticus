"""
    Script: sgd_clf.py
    Author: Lubin Maxime <maxime@soft.ics.keio.ac.jp>
    Date: 2013-07-24
    This module is part of the code I wrote for my master research project at Keio University (Japan)
    
    Classification experiment script. Perform random-stratified splitting
    of the data (70% for training), tune SGDClassifier with 10-fold
    corss-validation, test on unseen 30% and report.
    
    The above procedure can be repeated many times, generating lots of output.
    It is preferable to pipe stdout to a file. All the scores are stored
    on disk and can be summarized with pprint.py, or plotted with pr_plot.py.
    
    Args:
        str::dataset: name of the dataset to load
        str::experiment: "coarse" for binary classification, "fine" for multiclass
        str/int::select: final dataset selector. "cmp" to train only with linguistic features,
            "bow" to use only unigram features, "full" to use all features and
            an integer to use a hashed model (number of bits)
        int::n_iter: number of epoch for SGD
        int::nb_run: number of classification task to perform
        int::n_jobs: number of processors to use
        
    
    Return:
        None (print lots a data and save score under "clf_reports/dataset_name/")
"""

from virony import data

from sklearn.linear_model import SGDClassifier
from sklearn import metrics
from sklearn.cross_validation import train_test_split
from sklearn.grid_search import GridSearchCV
import cPickle
import numpy as np
import sys


########################################################################
########################################################################
#   Script parameters

dataset = sys.argv[1]
experiment = sys.argv[2]
select = sys.argv[3]
n_iter = int(sys.argv[4])
nb_run = int(sys.argv[5])
n_jobs = int(sys.argv[6])


if select not in ["bow","cmp","full"]:
    n_bits = int(select)
else:
    n_bits = 0


#   Script constants

cv = 10
param_grid = [  {'penalty':['l1', 'l2'], 'loss':['hinge', 'log', 'modified_huber']
                , 'alpha': [10e-6,10e-5,10e-4,10e-3,10e-2]},
            ]
score_func=metrics.f1_score
    
########################################################################
########################################################################
#   Load dataset

if n_bits==0:
    X,y, targetEncoder = data.load("dataset/"+dataset+"_"+experiment)

    ###########################
    # Special feature selection
    if select=="cmp":
        X = X[:,:14].todense() # "Complex" features only
    elif select=="bow":
        X = X[:, 14:]  # Bag-of-words only
    ###########################

else:
    X,y, targetEncoder = data.load("dataset/"+dataset+"_"+experiment+"_"+str(n_bits)+"bit")


########################################################################
########################################################################
#   Training->Testing Loop

confusions = np.zeros((nb_run, len(targetEncoder), len(targetEncoder)), dtype=float)
for run_id in range(0,nb_run):
        
    seeds = np.random.randint(1000, size=2)
    X_train, X_test, y_train, y_test = train_test_split(X,y,train_size=0.7, random_state=seeds[0])


    clf = GridSearchCV(SGDClassifier(random_state=seeds[1], shuffle=True, 
                        n_iter=n_iter, learning_rate="optimal"), param_grid,
                        score_func=score_func, verbose=True, n_jobs=n_jobs)
    clf.fit(X_train, y_train, cv=cv)

    y_pred, y_true = clf.predict(X_test), y_test
    confusions[run_id] = metrics.confusion_matrix(y_true, y_pred)
    accuracy = float(confusions[run_id].trace())/confusions[run_id].sum()

    report = metrics.classification_report(y_true, y_pred, target_names=map(str,targetEncoder.classes_)) + "\n"
    report += "Accuracy :"+str(accuracy)+"\n\n"
    report += str(clf.best_estimator_)+"\n\n"

    print "Run_id: ", run_id
    print
    print report
    print
    print "#################################################"
    print
    print


########################################################################
########################################################################
#   Save confusion matrices

if n_bits==0:
    with open("clf_reports/"+dataset+"/confusion_matrix_"+experiment+"_"+select+".pickle", "wb") as fout:
        cPickle.dump(confusions, fout)
else:
    with open("clf_reports/"+dataset+"/confusion_matrix_"+experiment+"_"+str(n_bits)+"bit.pickle", "wb") as fout:
        cPickle.dump(confusions, fout)

